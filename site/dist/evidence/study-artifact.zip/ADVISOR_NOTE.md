# Draft advisor note

Dear Professor Tamassia,

I would value your assessment of my experimental study, *Bucket Width, Duplicate
Work, and Local Lookahead in Sequential Shortest Paths*.

The central finding is that a mean-edge-weight bucket width provides useful
sequential speedups without a width search on the tested sparse and DIMACS road
graphs. My unchanged append-only solver reaches 1.97 times the speed of my
standard-library-heap Dijkstra on the 10,000-vertex sparse instances. With a cyclic
bucket array and duplicate suppression, the speed ratio is 1.82 at one million
vertices and 1.51-1.64 on three road networks. The Boost-documented
maximum-weight/maximum-degree rule performs comparably on those road inputs.

The mechanism study separates that sparse speedup from duplicate suppression:
suppression changes the dense ratio from 0.06 to 0.56 at 5,000 vertices, while
the heap remains faster. Degree-gated lookahead reduces the overhead of less
selective lookahead but never improves on the matched no-lookahead solver in
the 24 live core queries. The paper makes no asymptotic improvement or priority
claim for the width statistic.

The artifact includes raw paired timings, deterministic counters, held-out
sources, distance checks, and mechanism-removal tests. I would particularly
welcome your judgment on whether the controlled implementation comparisons
and measured operating range constitute a sufficiently focused contribution,
and which external SSSP implementation would be the most informative additional
baseline.

Best regards,
Bee Rosa Davis

## Discussion preparation

1. **What is the baseline?** My own Dijkstra using Rust's standard binary heap,
   lazy deletion, and settled flags. Explicit binary/4-ary and lazy radix heaps
   are additional implementations in the artifact. No externally maintained
   SSSP solver was timed; the road results establish performance relative to
   these implementations.
2. **What does this add to existing stepping algorithms and defaults?** A
   controlled comparison of width selection, bucket containers, and two sources
   of duplicate work, with explicit boundaries where a cheap rule helps or
   hurts. The Boost-style rule is competitive and appears in the results.
3. **How independent and repeatable are the observations?** Three synthetic
   seeds per setting, correlated transformations, and one machine. The seed
   intervals are descriptive. The independent rerun reproduces deterministic
   counts for fixed arms, but individual timing comparisons can change sign;
   calibration changes its multiplier on 21 of 48 laws configurations.
4. **Does it work on large real inputs?** NY, BAY, and COL have approximately
   264k-436k vertices; the synthetic scale panel reaches one million. Road
   speed depends on the bucket container and is also achieved by another cheap
   width rule. The synthetic road-like generator does not show the same gains.
5. **Why is suppression correct?** An unchanged label offers identical outgoing
   candidates; after light closure, a vertex's final label dominates its earlier
   heavy candidates. The smallest-bucket invariant supplies the ordering
   argument. Independent small-graph distance checks and removal tests cover
   the implementation; the exact label-equality check compares stored copies.

The note is a draft for review and has not been sent.
