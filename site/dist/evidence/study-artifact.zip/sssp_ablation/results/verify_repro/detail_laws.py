"""Drill into compare_laws.json: are all counts/width mismatches on selected_grid,
and do they map exactly onto selection.csv disagreements? List sign flips."""
import csv, json, sys
from collections import defaultdict

base = sys.argv[1]  # results dir
rep = json.load(open(f"{base}/verify_repro/compare_laws.json"))

# counts mismatches by arm
mm = rep["counts"]["keyed_field_mismatches"]
arms = defaultdict(int)
cases_mm = set()
for m in mm:
    case, src, arm = m["key"]
    arms[arm] += 1
    cases_mm.add(case)
print("counts mismatches by arm:", dict(arms), "| distinct cases:", sorted(cases_mm, key=int))

# selection disagreements
dis = rep["selection"]["disagree"]
dis_cases = {d["case"] for d in dis}
print("selection disagreements:", len(dis), "cases:", sorted(dis_cases, key=int))
print("counts-mismatch cases == selection-disagree cases:", cases_mm == dis_cases)
print("cases in mismatch but not in disagree:", sorted(cases_mm - dis_cases, key=int))
print("cases in disagree but not in mismatch:", sorted(dis_cases - cases_mm, key=int))
print()
print("case  fam                 ref_mult  new_mult  ref: best_ns vs new_choice_ns (margin%)   new: best_ns vs ref_choice_ns (margin%)")
fam = {}
with open(f"{base}/revision/laws/cases.csv", newline="") as f:
    for r in csv.DictReader(f):
        fam[r["case"]] = r["family"]
for d in sorted(dis, key=lambda d: int(d["case"])):
    mr, mn = d["medians_ref"], d["medians_new"]
    a, b = d["selected_ref"], d["selected_new"]
    ref_best, ref_alt = mr[a], mr[b]
    new_best, new_alt = mn[b], mn[a]
    print(f"{d['case']:>4}  {fam[d['case']]:<18} {a:>8}  {b:>8}  {ref_best:>9} vs {ref_alt:>9} ({100*(ref_alt-ref_best)/ref_best:+.1f}%)   {new_best:>9} vs {new_alt:>9} ({100*(new_alt-new_best)/new_best:+.1f}%)")

# width mismatches in samples: which arms?
wm = defaultdict(int)
ref_rows = list(csv.DictReader(open(f"{base}/revision/laws/samples.csv", newline="")))
new_rows = list(csv.DictReader(open(f"{base}/verify_repro/laws/samples.csv", newline="")))
for r1, r2 in zip(ref_rows, new_rows):
    if r1["width"] != r2["width"]:
        wm[(r1["stage"], r1["arm"])] += 1
print()
print("samples width mismatches by (stage,arm):", dict(wm))

# sign flips detail
print()
print("sign flips (recorded ratio vs new ratio, ratio = std_binary/arm):")
print("case  fam                 src   arm             ratio_ref  ratio_new")
flips = [r for r in rep["ratios"] if r["sign_flip"]]
for r in flips:
    print(f"{r['case']:>4}  {fam[str(r['case'])]:<18} {r['source']:>4}  {r['arm']:<14} {r['ratio_ref']:>9.4f}  {r['ratio_new']:>9.4f}")
# how far from 1 were the flips?
import statistics
print("flips: max |ratio_ref-1| =", max(abs(r["ratio_ref"] - 1) for r in flips), "; max |ratio_new-1| =", max(abs(r["ratio_new"] - 1) for r in flips))
print("flips by family:", dict(sorted(((f, sum(1 for r in flips if fam[str(r['case'])] == f)) for f in set(fam.values())), key=lambda x: -x[1])))
# non-flip: all ratio pairs on same side of 1 by arm and family group (sparse vs clustered)
grp = defaultdict(list)
for r in rep["ratios"]:
    grp[(fam[str(r["case"])].split("_")[0], r["arm"])].append(r)
print()
print("family-group x arm: geomean ratio ref vs new, flips/n")
import math
for (g, arm), rs in sorted(grp.items()):
    gr = math.exp(sum(math.log(x["ratio_ref"]) for x in rs) / len(rs))
    gn = math.exp(sum(math.log(x["ratio_new"]) for x in rs) / len(rs))
    print(f"{g:<10} {arm:<14} n={len(rs):>3}  ref={gr:.4f}  new={gn:.4f}  rel={(gn-gr)/gr:+.4f}  flips={sum(x['sign_flip'] for x in rs)}")
