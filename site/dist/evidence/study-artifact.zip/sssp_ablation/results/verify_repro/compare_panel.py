"""Case-by-case comparison of a re-run campaign panel against the recorded one.

Usage: python compare_panel.py <panel> <ref_dir> <new_dir> <out_prefix>

(a) counts.csv: exact row-for-row string equality (and keyed by case,source,arm).
    cases.csv: every non-timing column must match (n,m,seed,mean,median,max,sd,
    degree,max_degree,fingerprint); generation_ns/feature_ns are timings.
(b) samples.csv: validation rows only (stage != calibration); per (case,source,arm)
    median ns; ratio = median(std_binary)/median(arm), the analyze_revision.py:33
    convention ("Binary baseline / solve time"). Reports recorded ratio, new ratio,
    relative difference and sign flip for every (case,source,arm).
    Also checks the deterministic structure: the (case,source,arm,round,position)
    tuple set and the width column must match exactly.
(c) selection.csv: per case, the multiplier with selected==true must agree.
Uses only the standard library.
"""
import csv, json, statistics, sys
from collections import defaultdict

panel, ref_dir, new_dir, out_prefix = sys.argv[1:5]
REF_ARM = "std_binary"
report = {"panel": panel, "ref_dir": ref_dir, "new_dir": new_dir}
lines = []


def rows(path):
    with open(path, newline="") as f:
        r = list(csv.reader(f))
    return r[0], r[1:]


# ---------------------------------------------------------------- (a) counts.csv
h_ref, c_ref = rows(f"{ref_dir}/counts.csv")
h_new, c_new = rows(f"{new_dir}/counts.csv")
counts = {"header_equal": h_ref == h_new, "rows_ref": len(c_ref), "rows_new": len(c_new)}
row_mismatch = [i + 2 for i, (a, b) in enumerate(zip(c_ref, c_new)) if a != b]
counts["row_for_row_mismatch_lines"] = row_mismatch
counts["length_equal"] = len(c_ref) == len(c_new)
key = lambda r: (r[0], r[1], r[2])
d_ref = {key(r): r for r in c_ref}
d_new = {key(r): r for r in c_new}
counts["keys_only_in_ref"] = sorted(set(d_ref) - set(d_new))
counts["keys_only_in_new"] = sorted(set(d_new) - set(d_ref))
counts["keyed_field_mismatches"] = []
for k in sorted(set(d_ref) & set(d_new)):
    if d_ref[k] != d_new[k]:
        diffs = {h_ref[j]: (d_ref[k][j], d_new[k][j]) for j in range(len(h_ref)) if d_ref[k][j] != d_new[k][j]}
        counts["keyed_field_mismatches"].append({"key": k, "diffs": diffs})
counts["EXACT_MATCH"] = (
    counts["header_equal"] and counts["length_equal"] and not row_mismatch
)
with open(f"{ref_dir}/counts.csv", "rb") as f1, open(f"{new_dir}/counts.csv", "rb") as f2:
    counts["bytes_identical"] = f1.read() == f2.read()
report["counts"] = counts
lines.append(f"[counts.csv] rows ref={len(c_ref)} new={len(c_new)} header_equal={counts['header_equal']} "
             f"row_for_row_mismatches={len(row_mismatch)} bytes_identical={counts['bytes_identical']} "
             f"EXACT_MATCH={counts['EXACT_MATCH']}")

# ---------------------------------------------------------------- cases.csv
h_ref, k_ref = rows(f"{ref_dir}/cases.csv")
h_new, k_new = rows(f"{new_dir}/cases.csv")
timing_cols = {"generation_ns", "feature_ns"}
cases = {"rows_ref": len(k_ref), "rows_new": len(k_new), "header_equal": h_ref == h_new, "mismatches": []}
for a, b in zip(k_ref, k_new):
    for j, col in enumerate(h_ref):
        if col in timing_cols:
            continue
        if a[j] != b[j]:
            cases["mismatches"].append({"case": a[0], "col": col, "ref": a[j], "new": b[j]})
cases["DETERMINISTIC_MATCH"] = cases["header_equal"] and len(k_ref) == len(k_new) and not cases["mismatches"]
cases["fingerprints"] = [(a[0], a[2], a[-1], b[-1]) for a, b in zip(k_ref, k_new)]
report["cases"] = cases
lines.append(f"[cases.csv] rows ref={len(k_ref)} new={len(k_new)} non-timing mismatches={len(cases['mismatches'])} "
             f"DETERMINISTIC_MATCH={cases['DETERMINISTIC_MATCH']}")

# ---------------------------------------------------------------- (b) samples.csv
def load_samples(path):
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        return list(r)

s_ref = load_samples(f"{ref_dir}/samples.csv")
s_new = load_samples(f"{new_dir}/samples.csv")
tup = lambda r: (r["case"], r["stage"], r["source"], r["arm"], r["round"], r["position"])
t_ref = {tup(r): r for r in s_ref}
t_new = {tup(r): r for r in s_new}
structure = {
    "rows_ref": len(s_ref), "rows_new": len(s_new),
    "tuple_set_equal": set(t_ref) == set(t_new),
    "tuple_order_equal": [tup(r) for r in s_ref] == [tup(r) for r in s_new],
    "only_in_ref": len(set(t_ref) - set(t_new)), "only_in_new": len(set(t_new) - set(t_ref)),
}
width_mismatch = [(k, t_ref[k]["width"], t_new[k]["width"]) for k in t_ref if k in t_new and t_ref[k]["width"] != t_new[k]["width"]]
structure["width_mismatches"] = len(width_mismatch)
structure["width_mismatch_examples"] = width_mismatch[:5]
report["samples_structure"] = structure
lines.append(f"[samples.csv structure] rows ref={len(s_ref)} new={len(s_new)} tuple_set_equal={structure['tuple_set_equal']} "
             f"order_equal={structure['tuple_order_equal']} width_mismatches={len(width_mismatch)}")


def medians(samples):
    g = defaultdict(list)
    for r in samples:
        if r["stage"] == "calibration":
            continue
        g[(int(r["case"]), int(r["source"]), r["arm"])].append(int(r["ns"]))
    return {k: statistics.median(v) for k, v in g.items()}, {k: len(v) for k, v in g.items()}


m_ref, n_ref = medians(s_ref)
m_new, n_new = medians(s_new)
ratio_rows = []
flips = []
for k in sorted(set(m_ref) & set(m_new)):
    case, source, arm = k
    if arm == REF_ARM:
        continue
    b_ref = m_ref[(case, source, REF_ARM)]
    b_new = m_new[(case, source, REF_ARM)]
    r_ref = b_ref / m_ref[k]
    r_new = b_new / m_new[k]
    rel = (r_new - r_ref) / r_ref
    flip = (r_ref > 1) != (r_new > 1)
    row = {"case": case, "source": source, "arm": arm, "rounds_ref": n_ref[k], "rounds_new": n_new[k],
           "median_ns_ref": m_ref[k], "median_ns_new": m_new[k],
           "std_binary_ns_ref": b_ref, "std_binary_ns_new": b_new,
           "ratio_ref": r_ref, "ratio_new": r_new, "rel_diff": rel, "sign_flip": flip}
    ratio_rows.append(row)
    if flip:
        flips.append(row)
report["ratios"] = ratio_rows
report["ratio_summary"] = {
    "query_arms": len(ratio_rows),
    "sign_flips": len(flips),
    "abs_rel_diff_median": statistics.median(abs(r["rel_diff"]) for r in ratio_rows) if ratio_rows else None,
    "abs_rel_diff_max": max(abs(r["rel_diff"]) for r in ratio_rows) if ratio_rows else None,
    "within_10pct": sum(abs(r["rel_diff"]) <= 0.10 for r in ratio_rows),
    "within_25pct": sum(abs(r["rel_diff"]) <= 0.25 for r in ratio_rows),
    "over_50pct": sum(abs(r["rel_diff"]) > 0.50 for r in ratio_rows),
    "std_binary_abs_ns_ratio_new_over_ref": {
        "median": statistics.median(m_new[k] / m_ref[k] for k in m_ref if k[2] == REF_ARM and k in m_new),
    },
}
# arm-level aggregate: geometric mean of ratio across (case,source) for each arm
by_arm = defaultdict(list)
for r in ratio_rows:
    by_arm[r["arm"]].append(r)
import math
arm_agg = []
for arm, rs in sorted(by_arm.items()):
    g_ref = math.exp(sum(math.log(x["ratio_ref"]) for x in rs) / len(rs))
    g_new = math.exp(sum(math.log(x["ratio_new"]) for x in rs) / len(rs))
    arm_agg.append({"arm": arm, "n": len(rs), "geomean_ratio_ref": g_ref, "geomean_ratio_new": g_new,
                    "rel_diff": (g_new - g_ref) / g_ref,
                    "sign_flips": sum(x["sign_flip"] for x in rs),
                    "median_abs_rel_diff": statistics.median(abs(x["rel_diff"]) for x in rs)})
report["arm_aggregate"] = arm_agg
lines.append(f"[ratios] query-arms={len(ratio_rows)} sign_flips={len(flips)} "
             f"median|rel|={report['ratio_summary']['abs_rel_diff_median']:.4f} max|rel|={report['ratio_summary']['abs_rel_diff_max']:.4f} "
             f"within10%={report['ratio_summary']['within_10pct']} within25%={report['ratio_summary']['within_25pct']} over50%={report['ratio_summary']['over_50pct']} "
             f"std_binary abs-ns new/ref median={report['ratio_summary']['std_binary_abs_ns_ratio_new_over_ref']['median']:.3f}")
lines.append("arm                 n   geo_ref   geo_new   rel_diff  flips  med|rel|")
for a in arm_agg:
    lines.append(f"{a['arm']:<18} {a['n']:>3} {a['geomean_ratio_ref']:>9.4f} {a['geomean_ratio_new']:>9.4f} {a['rel_diff']:>+9.4f} {a['sign_flips']:>6} {a['median_abs_rel_diff']:>8.4f}")
lines.append("")
lines.append("case src arm                 rnds  ref_ns_ref  ref_ns_new  arm_ns_ref  arm_ns_new  ratio_ref  ratio_new  rel_diff  flip")
for r in ratio_rows:
    lines.append(f"{r['case']:>4} {r['source']:>4} {r['arm']:<18} {r['rounds_ref']:>2}/{r['rounds_new']:<2} "
                 f"{r['std_binary_ns_ref']:>11.0f} {r['std_binary_ns_new']:>11.0f} {r['median_ns_ref']:>11.0f} {r['median_ns_new']:>11.0f} "
                 f"{r['ratio_ref']:>10.4f} {r['ratio_new']:>10.4f} {r['rel_diff']:>+9.4f}  {'FLIP' if r['sign_flip'] else ''}")

# ---------------------------------------------------------------- (c) selection.csv
def selections(path):
    sel = defaultdict(dict)
    chosen = {}
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            sel[r["case"]][r["multiplier"]] = int(r["median_ns"])
            if r["selected"] == "true":
                chosen[r["case"]] = r["multiplier"]
    return sel, chosen

sel_ref, ch_ref = selections(f"{ref_dir}/selection.csv")
sel_new, ch_new = selections(f"{new_dir}/selection.csv")
sel_rows = []
for c in sorted(set(ch_ref) | set(ch_new), key=int):
    sel_rows.append({"case": c, "selected_ref": ch_ref.get(c), "selected_new": ch_new.get(c),
                     "agree": ch_ref.get(c) == ch_new.get(c),
                     "medians_ref": sel_ref.get(c), "medians_new": sel_new.get(c)})
report["selection"] = {"cases": len(sel_rows), "agree": sum(r["agree"] for r in sel_rows),
                       "disagree": [r for r in sel_rows if not r["agree"]], "rows": sel_rows}
lines.append("")
lines.append(f"[selection.csv] cases={len(sel_rows)} agree={report['selection']['agree']} disagree={len(report['selection']['disagree'])}")
for r in sel_rows:
    if not r["agree"]:
        # show the two best candidates in each run
        b_ref = sorted(r["medians_ref"].items(), key=lambda kv: kv[1])[:3]
        b_new = sorted(r["medians_new"].items(), key=lambda kv: kv[1])[:3]
        lines.append(f"  case {r['case']}: ref={r['selected_ref']} new={r['selected_new']} | ref top3={b_ref} | new top3={b_new}")

with open(f"{out_prefix}.json", "w") as f:
    json.dump(report, f, indent=1, default=str)
with open(f"{out_prefix}.txt", "w") as f:
    f.write("\n".join(lines) + "\n")
print("\n".join(lines))
