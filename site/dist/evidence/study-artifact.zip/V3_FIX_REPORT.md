# v3 reporting and artifact fixes

The revised paper credits the unchanged List solver's sparse result and separates
it from the dense-work benefit of suppression. The original verification report
is preserved as a review input; this file records the applied changes.

1. Abstract reports List and Map separately at n=5000, List's 1.97 ratio at
   n=10000, and the dense suppression comparison.
2. The live core count is computed from the raw core counters and admission data.
3. The scale/road table includes the maximum-weight/maximum-degree rule and
   calibrated width alongside all its previous arms. The prose identifies their
   containers and derives the within-road spread from unrounded ratios.
4. The standard-heap Dijkstra baseline and unchanged author List solver are named
   explicitly. No external solver is claimed as measured.
5. Both sources of layout case 29 are excluded from the manuscript summary.
   Raw rows and original all-case tables remain intact. The synchronization
   attribution comes from the supplied verification report, not a new process
   trace. The retained population and its smaller BFS sample are documented.
6. The selected-width argmin is explicitly session-specific; the 21/48 different
   laws-panel selections are supported by the included independent rerun files.
7. Grid and road-like synthetic configurations now appear in the core table.
8. The degree sweep states the low-degree, peak, degree-64, and dense endpoints.
9. High-K results are reported. Null comparisons remain descriptive, without an
   unsupported equivalence claim. Engine feature-extraction latency is not
   implied to have been timed. Substrate text is parsed from saved PASS output
   and measured vertex count.
10. Correctness-test scope, common factorial bookkeeping, Std heap labels,
    implementation-specific radix results, cache source, and normalized spelling
    are clarified. The smallest-bucket invariant and stored-label comparison are
    stated. The source snapshot shows four tests before measurement, followed by
    two additional tests and a strengthened fixture, not four added tests.
11. The manifest distinguishes measured from current source hashes. A documented
    reconstruction of the launch driver is included. Snapshot checking uses
    rustfmt-normalized production code; mutation reruns require a fresh output
    directory. Smoke provenance and test target-directory invocations are recorded.

## Review statements narrowed to match evidence

- List is not the fastest sparse bucket arm at every size: Ring has larger
  paired ratios at n=1000, 2000, and 5000. Median solve times and geometric paired
  ratios are different summaries. The paper does not infer a resolved win merely
  from a small ordering difference.
- Suppression greatly reduces dense slowdown; a 0.56 ratio still loses to the
  heap and does not make mean width universally safe or fast.
- The saved independent rerun details contain individual-query sign changes for
  bucket arms. Stability of an aggregate is not universal sign preservation.
- Counts against permutation medians do not prove statistical equivalence to a
  null. The paper reports the observations without that inference.
- A reconstructed driver helps future reproduction but cannot retroactively
  establish the identity of the original launch script.

The advisor note is provided separately as an unsent draft. No new performance
measurements are required for these reporting changes.

## Validation

The revised PDF compiles to 15 pages with no LaTeX warnings or overflowing boxes;
all pages were rendered and visually inspected. The source verifier confirms both
archived hashes and identical production code after rustfmt. A fresh isolated
mutation run passes the control and fails each removed mechanism. The launch
driver passes argument validation and a separate smoke execution whose counters
are byte-identical to the archived smoke counters. This smoke execution is a
driver check, not a replacement performance panel. Its logs and the fresh
mutation logs accompany the package, separate from primary measurement files.
